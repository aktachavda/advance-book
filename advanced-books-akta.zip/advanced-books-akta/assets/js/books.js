jQuery(document).ready(function ($) {
    function loadBooks(page = 1) {
        const author = $('#filter-author').val();
        const price = $('#filter-price').val();
        const sort = $('#filter-sort').val();

        $.post(advancedBooksAjax.ajax_url, {
            action: 'load_books',
            author: author,
            price: price,
            sort: sort,
            page: page,
        }, function (response) {
            $('#books-list').html(response);
        });
    }

    $('#apply-filters').on('click', function () {
        loadBooks(1);
    });

    $(document).on('click', '.page-btn', function () {
        const page = $(this).data('page');
        loadBooks(page);
    });

    // Initial load
    loadBooks();
});
