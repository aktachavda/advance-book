<?php
/**
 * Plugin Name: Advanced Books
 * Description: A custom plugin to list books with filters, AJAX pagination, caching, and REST API.
 * Version: 1.0
 * Author: Akta
 */

defined( 'ABSPATH' ) || exit;

require_once plugin_dir_path(__FILE__) . 'includes/class-advanced-books-cpt.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-advanced-books-shortcode.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-advanced-books-ajax.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-advanced-books-cache.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-advanced-books-rest-api.php';

add_action( 'plugins_loaded', function() {
    new Advanced_Books_CPT();
    new Advanced_Books_Shortcode();
    new Advanced_Books_AJAX();
    new Advanced_Books_Cache();
    new Advanced_Books_REST_API();
});
