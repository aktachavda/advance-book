<?php
defined('ABSPATH') || exit;

class Advanced_Books_REST_API {
    public function __construct() {
        add_action('rest_api_init', function () {
            register_rest_route('books/v1', '/list', [
                'methods' => 'GET',
                'callback' => [$this, 'get_books'],
                'permission_callback' => '__return_true',
            ]);
        });
    }

    public function get_books($request) {
        $author = sanitize_text_field($request->get_param('author'));
        $price_range = sanitize_text_field($request->get_param('price_range'));
        $sort_by = sanitize_text_field($request->get_param('sort_by'));
        $paged = absint($request->get_param('page')) ?: 1;

        $meta_query = ['relation' => 'AND'];

        if ($author) {
            $meta_query[] = [
                'key' => '_book_author',
                'value' => '^' . $author,
                'compare' => 'REGEXP',
            ];
        }

        if ($price_range && strpos($price_range, '-') !== false) {
            list($min, $max) = explode('-', $price_range);
            $meta_query[] = [
                'key' => '_book_price',
                'value' => [(float)$min, (float)$max],
                'type' => 'NUMERIC',
                'compare' => 'BETWEEN',
            ];
        }

        $args = [
            'post_type' => 'book',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'paged' => $paged,
            'meta_query' => $meta_query,
        ];

        if ($sort_by === 'oldest') {
            $args['orderby'] = 'meta_value';
            $args['meta_key'] = '_book_publish_date';
            $args['order'] = 'ASC';
        } else {
            $args['orderby'] = 'meta_value';
            $args['meta_key'] = '_book_publish_date';
            $args['order'] = 'DESC';
        }

        $query = new WP_Query($args);

        $books = [];
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $books[] = [
                    'title' => get_the_title(),
                    'author' => get_post_meta(get_the_ID(), '_book_author', true),
                    'price' => get_post_meta(get_the_ID(), '_book_price', true),
                    'publish_date' => get_post_meta(get_the_ID(), '_book_publish_date', true),
                    'link' => get_permalink(),
                ];
            }
        }

        wp_reset_postdata();

        return rest_ensure_response([
            'success' => true,
            'data' => $books,
            'total' => $query->found_posts,
            'pages' => $query->max_num_pages,
        ]);
    }
}
