<?php
defined('ABSPATH') || exit;

class Advanced_Books_Shortcode {
    public function __construct() {
        add_shortcode('advanced_books', [$this, 'render_books_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function enqueue_assets() {
        wp_enqueue_style('advanced-books-css', plugin_dir_url(__FILE__) . '../assets/css/books.css', [], '1.0');
        wp_enqueue_script('advanced-books-js', plugin_dir_url(__FILE__) . '../assets/js/books.js', ['jquery'], '1.0', true);

        wp_localize_script('advanced-books-js', 'advancedBooksAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
        ]);
    }

    public function render_books_shortcode($atts) {
        ob_start();
        ?>
        <div class="advanced-books-filters">
            <label>Author Starts With:
                <select id="filter-author">
                    <option value="">All</option>
                    <?php
                $authors = $this->get_authors();
                foreach ( $authors as $author ) {
                    echo '<option value="' . esc_attr( $author ) . '">' . esc_html( $author ) . '</option>';
                }
                ?>
                </select>
            </label>

            <label>Price Range:
                <select id="filter-price">
                    <option value="">All</option>
                    <option value="50-100">$50 - $100</option>
                    <option value="100-150">$100 - $150</option>
                    <option value="150-200">$150 - $200</option>
                </select>
            </label>

            <label>Sort By:
                <select id="filter-sort">
                    <option value="newest">Newest</option>
                    <option value="oldest">Oldest</option>
                </select>
            </label>

            <button id="apply-filters">Apply Filters</button>
        </div>

        <div id="books-list"></div>
        <div id="books-pagination"></div>
        <?php
        return ob_get_clean();
    }

    public function get_authors() {
        $args = [
            'post_type' => 'book',
            'posts_per_page' => -1,
            'fields' => 'ids',
        ];
        $query = new WP_Query( $args );
        $authors = [];
        foreach ( $query->posts as $post_id ) {
            $author = get_post_meta( $post_id, '_book_author', true );
            if ( $author && ! in_array( $author, $authors ) ) {
                $authors[] = $author;
            }
        }
        sort( $authors );
        return $authors;
    }
}