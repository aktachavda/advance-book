<?php
defined('ABSPATH') || exit;

class Advanced_Books_Cache {
    public function __construct() {
        // Optional: flush cache on post save
        add_action('save_post_book', [$this, 'clear_books_cache']);
    }

    public function get_cached_books($args, $cache_key) {
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $query = new WP_Query($args);
        set_transient($cache_key, $query, HOUR_IN_SECONDS);
        return $query;
    }

    public function clear_books_cache($post_id) {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_%_books_cache_%'");
    }

    public static function generate_cache_key($filters) {
        return 'books_cache_' . md5(json_encode($filters));
    }
}
