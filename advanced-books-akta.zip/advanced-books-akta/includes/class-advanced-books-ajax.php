<?php
defined('ABSPATH') || exit;

class Advanced_Books_AJAX {
    public function __construct() {
        add_action('wp_ajax_load_books', [$this, 'handle_ajax']);
        add_action('wp_ajax_nopriv_load_books', [$this, 'handle_ajax']);
    }

    public function handle_ajax() {
        $author_letter = isset($_POST['author']) ? sanitize_text_field($_POST['author']) : '';
        $price_range = isset($_POST['price']) ? sanitize_text_field($_POST['price']) : '';
        $sort_by = isset($_POST['sort']) ? sanitize_text_field($_POST['sort']) : '';
        $paged = isset($_POST['page']) ? absint($_POST['page']) : 1;

        $meta_query = ['relation' => 'AND'];

        if ($author_letter) {
            $meta_query[] = [
                'key' => '_book_author',
                'value' => '^' . $author_letter,
                'compare' => 'REGEXP',
            ];
        }

        if ($price_range) {
            list($min, $max) = explode('-', $price_range);
            $meta_query[] = [
                'key' => '_book_price',
                'value' => [$min, $max],
                'type' => 'NUMERIC',
                'compare' => 'BETWEEN',
            ];
        }

        $args = [
            'post_type' => 'book',
            'post_status' => 'publish',
            'posts_per_page' => 3,
            'paged' => $paged,
            'meta_query' => $meta_query,
            'no_found_rows' => false,
        ];

        if ($sort_by === 'oldest') {
            $args['orderby'] = 'meta_value';
            $args['meta_key'] = '_book_publish_date';
            $args['order'] = 'ASC';
        } else {
            $args['orderby'] = 'meta_value';
            $args['meta_key'] = '_book_publish_date';
            $args['order'] = 'DESC';
        }

        $query = new WP_Query($args);

        ob_start();
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $author = get_post_meta(get_the_ID(), '_book_author', true);
                $price = get_post_meta(get_the_ID(), '_book_price', true);
                $publish_date = get_post_meta(get_the_ID(), '_book_publish_date', true);
                ?>
                <div class="book-item">
                    <h3><?php the_title(); ?></h3>
                    <p><strong>Author:</strong> <?php echo esc_html($author); ?></p>
                    <p><strong>Price:</strong> $<?php echo esc_html($price); ?></p>
                    <p><strong>Published:</strong> <?php echo esc_html($publish_date); ?></p>
                </div>
                <hr>
                <?php
            }

            echo '<div class="pagination">';
            for ($i = 1; $i <= $query->max_num_pages; $i++) {
                echo '<button class="page-btn" data-page="' . $i . '">' . $i . '</button> ';
            }
            echo '</div>';
        } else {
            echo '<p>No books found.</p>';
        }
        wp_reset_postdata();

        echo ob_get_clean();
        wp_die();
    }
}
