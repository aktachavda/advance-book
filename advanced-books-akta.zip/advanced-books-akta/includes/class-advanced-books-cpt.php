<?php
// Exit if accessed directly
defined('ABSPATH') || exit;

class Advanced_Books_CPT {
    public function __construct() {
        add_action('init', [$this, 'register_books_post_type']);
        add_action('add_meta_boxes', [$this, 'register_meta_boxes']);
        add_action('save_post', [$this, 'save_book_meta']);
    }

    public function register_books_post_type() {
        $labels = [
            'name' => 'Books',
            'singular_name' => 'Book',
            'add_new' => 'Add New',
            'add_new_item' => 'Add New Book',
            'edit_item' => 'Edit Book',
            'new_item' => 'New Book',
            'view_item' => 'View Book',
            'search_items' => 'Search Books',
            'not_found' => 'No books found',
            'not_found_in_trash' => 'No books found in Trash',
            'all_items' => 'All Books',
            'menu_name' => 'Books',
            'name_admin_bar' => 'Book',
        ];

        $args = [
            'labels' => $labels,
            'public' => true,
            'has_archive' => true,
            'menu_position' => 5,
            'supports' => ['title', 'editor', 'thumbnail'],
            'menu_icon' => 'dashicons-book',
            'show_in_rest' => true,
        ];

        register_post_type('book', $args);
    }

    public function register_meta_boxes() {
        add_meta_box('book_meta', 'Book Details', [$this, 'render_meta_box'], 'book', 'normal', 'default');
    }

    public function render_meta_box($post) {
        $author_name = get_post_meta($post->ID, '_book_author', true);
        $price = get_post_meta($post->ID, '_book_price', true);
        $publish_date = get_post_meta($post->ID, '_book_publish_date', true);

        wp_nonce_field('save_book_meta', 'book_meta_nonce');
        ?>
        <p>
            <label>Author Name:</label><br>
            <input type="text" name="book_author" value="<?php echo esc_attr($author_name); ?>" />
        </p>
        <p>
            <label>Price ($):</label><br>
            <input type="number" name="book_price" value="<?php echo esc_attr($price); ?>" step="0.01" />
        </p>
        <p>
            <label>Publish Date:</label><br>
            <input type="date" name="book_publish_date" value="<?php echo esc_attr($publish_date); ?>" />
        </p>
        <?php
    }

    public function save_book_meta($post_id) {
        if (!isset($_POST['book_meta_nonce']) || !wp_verify_nonce($_POST['book_meta_nonce'], 'save_book_meta')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

        if (isset($_POST['book_author'])) {
            update_post_meta($post_id, '_book_author', sanitize_text_field($_POST['book_author']));
        }

        if (isset($_POST['book_price'])) {
            update_post_meta($post_id, '_book_price', floatval($_POST['book_price']));
        }

        if (isset($_POST['book_publish_date'])) {
            update_post_meta($post_id, '_book_publish_date', sanitize_text_field($_POST['book_publish_date']));
        }
    }
}
